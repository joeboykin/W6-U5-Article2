package com.codepath.articlesearch.presentation.main.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.codepath.articlesearch.R
import com.codepath.articlesearch.data.model.DisplayArticle
import com.codepath.articlesearch.presentation.detail.DetailActivity

const val ARTICLE_EXTRA = "ARTICLE_EXTRA"
private const val TAG = "ArticleAdapter"

class ArticleAdapter(private val context: Context, val articles: List<DisplayArticle>) :
    RecyclerView.Adapter<ArticleAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_article, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // TODO: Get the individual article and bind to holder
        val article = articles[position]
        holder.bind(article)
    }


    override fun getItemCount() = articles.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener {

        private val mediaImageView = itemView.findViewById<ImageView>(R.id.mediaImage)
        private val titleTextView: TextView = itemView.findViewById(R.id.mediaTitle)
        private val abstractTextView: TextView = itemView.findViewById(R.id.mediaAbstract)

        init {
            itemView.setOnClickListener(this)
        }

        // TODO: Write a helper method to help set up the onBindViewHolder method
        fun bind(article: DisplayArticle) {
            val baseUrl = "https://static01.nyt.com/"
            if (article.mediaImageUrl.isNullOrEmpty())
                mediaImageView.setImageDrawable(null)
            else
                Glide.with(context).load(baseUrl + article.mediaImageUrl).centerCrop()
                    .into(mediaImageView)
            titleTextView.text = article.headline
            abstractTextView.text = article.abstract
        }


        override fun onClick(v: View?) {
            // TODO: Get selected article

            // TODO: Navigate to Details screen and pass selected article

            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                val article = articles[position]
                val bundle = Bundle()
                bundle.putString("title", article.headline)
                if (!article.mediaImageUrl.isNullOrEmpty())
                    bundle.putString("url", article.mediaImageUrl)

                if (!article.byline.isNullOrEmpty())
                    bundle.putString("byline", article.byline)
                bundle.putString("abstract", article.abstract)
                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtra("article", bundle)
                context.startActivity(intent)
            }
        }
    }
}