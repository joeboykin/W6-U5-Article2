package com.codepath.articlesearch.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.codepath.articlesearch.data.model.ArticleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ArticleDao {
    @Query("SELECT * FROM article_table")
    fun getAll(): Flow<List<ArticleEntity>>


    @Insert
    fun insertAll(articles: List<ArticleEntity>)

    @Query("DELETE FROM article_table")
    fun deleteAll()}
