package com.codepath.articlesearch.presentation.main

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.codepath.articlesearch.BuildConfig
import com.codepath.articlesearch.R
import com.codepath.articlesearch.Response
import com.codepath.articlesearch.data.model.ArticleEntity
import com.codepath.articlesearch.data.model.DisplayArticle
import com.codepath.articlesearch.databinding.ActivityMainBinding
import com.codepath.articlesearch.presentation.ArticleApplication
import com.codepath.articlesearch.presentation.main.adapter.ArticleAdapter
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import okhttp3.Headers
import org.json.JSONException

private const val TAG = "MainActivity/"
private const val SEARCH_API_KEY = BuildConfig.API_KEY
private const val ARTICLE_SEARCH_URL =
    "https://api.nytimes.com/svc/search/v2/articlesearch.json?api-key=${SEARCH_API_KEY}"

class MainActivity : AppCompatActivity() {
    private lateinit var articlesRecyclerView: RecyclerView
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        articlesRecyclerView = findViewById(R.id.articles)
        // TODO: Set up ArticleAdapter with articles.



        articlesRecyclerView.layoutManager = LinearLayoutManager(this).also {
            val dividerItemDecoration = DividerItemDecoration(this, it.orientation)
            articlesRecyclerView.addItemDecoration(dividerItemDecoration)
        }

        val articles = mutableListOf<DisplayArticle>()
        val articleAdapter = ArticleAdapter(this@MainActivity, articles)

        articlesRecyclerView.adapter=articleAdapter

        lifecycleScope.launch {
            (application as ArticleApplication).db.articleDao().getAll().collect { databaseList ->
                databaseList.map { entity ->
                    DisplayArticle(
                        entity.headline,
                        entity.articleAbstract,
                        entity.byline,
                        entity.mediaImageUrl
                    )
                }.also { mappedList ->
                    articles.clear()
                    articles.addAll(mappedList)

                    Log.d(TAG,mappedList.toString())
                    articleAdapter.notifyDataSetChanged()
                }
            }
        }

        setAndRetrieveData()




    }

    private fun setAndRetrieveData() {
        val client = AsyncHttpClient()
        client.get(ARTICLE_SEARCH_URL, object : JsonHttpResponseHandler() {
            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                Log.e(TAG, "Failed to fetch articles: $statusCode")
            }

            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                Log.i(TAG, json.toString())
                try {
                    val jsonObject =
                        json.jsonObject // extract the JSON object from the query parameter

                    // TODO: Create the parsedJSON
                    val gson = Gson()
                    val response: Response =
                        gson.fromJson(jsonObject.toString(), Response::class.java)
                    val articles = response.response?.docs

                    if (articles != null) {
                        lifecycleScope.launch(IO) {
                            (application as ArticleApplication).db.articleDao().deleteAll()
                            (application as ArticleApplication).db.articleDao()
                                .insertAll(articles.map {
                                    ArticleEntity(
                                        headline = it.headline?.main,
                                        articleAbstract = it.abstract,
                                        byline = it.byline?.original,
                                        mediaImageUrl = it.multimedia?.let {
                                            if (it.isNullOrEmpty())
                                                ""
                                            else
                                                it[0].url
                                        } ?: ""
                                    )
                                })
                        }
                    }

                } catch (e: JSONException) {
                    Log.e(TAG, "Exception: $e")
                }
            }

        })
    }
}