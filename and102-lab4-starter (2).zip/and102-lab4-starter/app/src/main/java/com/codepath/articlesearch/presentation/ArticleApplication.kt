package com.codepath.articlesearch.presentation

import android.app.Application
import com.codepath.articlesearch.data.database.AppDatabase

class ArticleApplication : Application() {
    val db by lazy { AppDatabase.getInstance(this) }
}