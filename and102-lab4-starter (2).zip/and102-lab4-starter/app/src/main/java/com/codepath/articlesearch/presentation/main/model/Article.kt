package com.codepath.articlesearch

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


data class Response(
    val status:String?,
    val copyright : String?,
    val response : Docs?
)

data class Docs(
    val docs : List<Article>?
)


@Parcelize
data class Article(
    val web_url:String?,
    val abstract : String?,
    val multimedia:List<Multimedia>?,
    val headline: Headline?,
    val byline: Byline?,
) : Parcelable

@Parcelize
data class Multimedia(
    val url:String,
    val caption:String
) : Parcelable


@Parcelize
data class Headline(
    val main:String,
    val name:String,
):Parcelable

@Parcelize
data class Byline(
    val original : String,
    val person:List<Person>,
    val organization:String
):Parcelable

@Parcelize
data class Person(
    val firstname:String,
    val middlename:String,
    val lastname:String,
    val title:String
):Parcelable